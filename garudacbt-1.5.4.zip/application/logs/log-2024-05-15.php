<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-15 12:05:39 --> Severity: Warning --> Attempt to read property "id" on null C:\laragon\www\umbk\application\controllers\Auth.php 33
ERROR - 2024-05-15 12:05:39 --> Severity: Warning --> Attempt to read property "name" on null C:\laragon\www\umbk\application\controllers\Auth.php 34
ERROR - 2024-05-15 12:05:48 --> Severity: Warning --> Attempt to read property "id" on null C:\laragon\www\umbk\application\controllers\Auth.php 33
ERROR - 2024-05-15 12:05:48 --> Severity: Warning --> Attempt to read property "name" on null C:\laragon\www\umbk\application\controllers\Auth.php 34
ERROR - 2024-05-15 12:05:53 --> Severity: Warning --> Attempt to read property "id" on null C:\laragon\www\umbk\application\controllers\Auth.php 33
ERROR - 2024-05-15 12:05:53 --> Severity: Warning --> Attempt to read property "name" on null C:\laragon\www\umbk\application\controllers\Auth.php 34
